﻿var MainContent = React.createClass({
    getInitialState: function () {
        return {};
    },

    componentDidMount: function () {
    },

    componentDidUpdate: function(prevProps, prevState){
    },

    render: function () {
        return (
            <div />
        );
    }
});




React.render(
    <MainContent />
    ,
    document.getElementById('main-content')
);